/* WorldMind uygulama çalışanı: kurulabilir uygulama için. Haberler her zaman canlı çekilir (önbelleğe alınmaz). */
const C = "wm-shell-v1";
self.addEventListener("install", (e) => { e.waitUntil(caches.open(C).then((c) => c.addAll(["./", "wm-icon-192.png", "wm-icon-512.png"]).catch(() => {}))); self.skipWaiting(); });
self.addEventListener("activate", (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== C).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", (e) => {
  if (e.request.mode !== "navigate") return;                          // yalnızca sayfanın kendisi: önce internet, yoksa son kayıtlı sürüm
  e.respondWith(fetch(e.request).then((r) => { const cp = r.clone(); caches.open(C).then((c) => c.put("./", cp)); return r; }).catch(() => caches.match("./")));
});
